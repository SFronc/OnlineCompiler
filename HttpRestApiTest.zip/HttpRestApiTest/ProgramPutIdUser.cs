using System.Net;
using System.Text.Json;

namespace RestApiTest
{

    public class ProgramPutIdUser
    {

        static void Mainpui(string[] args)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5023/api/User/3");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "PUT";

            httpWebRequest.Headers["X-API-Username"] = "test2";  
            httpWebRequest.Headers["X-API-Key"] = "c7fec1bc-870c-47d7-aac4-7dfd15fd10cb";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonSerializer.Serialize(new
                {
                    id = 3,
                    Username="test2",
                    PasswordHash = "New password ahsh",
                    Email = "t@t.a"
                });
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.WriteLine(result);
            }

        }

    }
}

