using System.Net;
using System.Text.Json;

namespace RestApiTest
{

    public class ProgramGetFileModel
    {

        static void Maingetfilemodel(string[] args)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5023/api/FileModel");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "GET";

            httpWebRequest.Headers["X-API-Username"] = "admin";  
            httpWebRequest.Headers["X-API-Key"] = "e5ee2907-7150-400e-af5a-3fe47b54351d";

            //httpWebRequest.Headers["X-API-Username"] = "a";
            //httpWebRequest.Headers["X-API-Key"] = "d9399374-1310-4f74-91cb-40bed2b4ad2f";


            try
            {
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    Console.WriteLine(result);
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("Błąd żądania: " + ex.Message);

                using var responseStream = ex.Response?.GetResponseStream();
                if (responseStream != null)
                {
                    using var reader = new StreamReader(responseStream);
                    Console.WriteLine("Odpowiedź serwera: " + reader.ReadToEnd());
                }
            }
        }

    }
}

