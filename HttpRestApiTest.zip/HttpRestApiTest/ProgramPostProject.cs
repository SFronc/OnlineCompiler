using System.Net;
using System.Text.Json;

namespace RestApiTest
{

    public class ProgramPostProject
    {

        static void Mainpostproject(string[] args)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5023/api/Project");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";

            httpWebRequest.Headers["X-API-Username"] = "admin";
            httpWebRequest.Headers["X-API-Key"] = "e5ee2907-7150-400e-af5a-3fe47b54351d";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonSerializer.Serialize(new
                {
                    Name = "testProj2",
                    Description = "testDesc",
                    UserId = 1
                });
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.WriteLine(result);
            }

        }

    }
}

