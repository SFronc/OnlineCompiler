using System.Net;
using System.Text.Json;

namespace RestApiTest
{

    public class ProgramDeleteUser
    {

        static void Maindu(string[] args)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5023/api/User/3");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "DELETE";

            httpWebRequest.Headers["X-API-Username"] = "admin";  
            httpWebRequest.Headers["X-API-Key"] = "ae34cc50-43d7-4f21-b747-8eab113ef87d";

            try
            {
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    Console.WriteLine(result);
                }
            }
            catch (WebException ex)
            {
                Console.WriteLine("Błąd żądania: " + ex.Message);

                using var responseStream = ex.Response?.GetResponseStream();
                if (responseStream != null)
                {
                    using var reader = new StreamReader(responseStream);
                    Console.WriteLine("Odpowiedź serwera: " + reader.ReadToEnd());
                }
            }

        }

    }
}

