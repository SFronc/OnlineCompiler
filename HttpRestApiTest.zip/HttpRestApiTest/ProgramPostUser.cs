using System.Net;
using System.Text.Json;

namespace RestApiTest
{

    public class ProgramPostUser
    {

        static void Mainppu(string[] args)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5023/api/User");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";

            httpWebRequest.Headers["X-API-Username"] = "admin";
            httpWebRequest.Headers["X-API-Key"] = "ae34cc50-43d7-4f21-b747-8eab113ef87d";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonSerializer.Serialize(new
                {
                    Username = "test2",
                    PasswordHash = "testhashpasswor",
                    Role = "User"
                });
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.WriteLine(result);
            }


        }

    }
}

