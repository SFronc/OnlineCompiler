using System.Net;
using System.Text.Json;

namespace RestApiTest
{

    public class ProgramPutIdProject
    {

        static void Mainputidproject(string[] args)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost:5023/api/Project/3");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "PUT";

            httpWebRequest.Headers["X-API-Username"] = "admin";
            httpWebRequest.Headers["X-API-Key"] = "e5ee2907-7150-400e-af5a-3fe47b54351d";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = JsonSerializer.Serialize(new
                {
                    Name = "Updated Project Name",
                    Description = "New description for the project",
                    isPublic = true,
                    UserId = 2 
                });
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.WriteLine(result);
            }

        }

    }
}

